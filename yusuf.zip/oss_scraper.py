import requests
import re
import json

class OssScraper:
    def __init__(self):
        self.base_url = "https://www.bpjsketenagakerjaan.go.id"
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        })

    def get_initial_tokens(self):
        print("[*] Initializing session and fetching tokens...")
        # Step 0: Auth to get cookies
        auth_url = "https://www.bpjsketenagakerjaan.go.id/oss?token=ZW1haWw9U05MTlVUUkFDRVVUSUNBTEBHTUFJTC5DT00mbmliPTAyMjA0MDAyNjA4NTY="
        try:
            print("[*] Authenticating...")
            self.session.get(auth_url, timeout=15)
        except Exception as e:
            print(f"[-] Auth Error: {e}")

        # Step 1: Get CSRF and Oauth
        url = f"{self.base_url}/oss/input-tk"
        try:
            resp = self.session.get(url, timeout=15)
            # Ambil CSRF token dari javascript data: { ... _csrf:'...' }
            csrf_match = re.search(r"_csrf\s*:\s*'([^']+)'", resp.text)
            csrf_token = csrf_match.group(1) if csrf_match else None
            
            # Ambil oauth token jika ada
            oauth_match = re.search(r"oauth\s*:\s*'([^']+)'", resp.text)
            oauth_token = oauth_match.group(1) if oauth_match else None
            
            return csrf_token, oauth_token
        except Exception as e:
            print(f"[-] Error initializing: {e}")
            return None, None

    def check_kpj(self, kpj, csrf_token, oauth_token):
        print(f"[*] Checking KPJ: {kpj}...")
        url = f"{self.base_url}/oss/cekKPJ"
        payload = {
            "kpj": kpj,
            "oauth": oauth_token,
            "_csrf": csrf_token
        }
        headers = {
            "X-Requested-With": "XMLHttpRequest",
            "Referer": f"{self.base_url}/oss/input-tk",
            "Origin": self.base_url,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        }
        try:
            resp = self.session.post(url, data=payload, headers=headers, timeout=15)
            try:
                return resp.json()
            except:
                print(f"[-] Response is not JSON. Status: {resp.status_code}")
                print(f"[-] Response content: {resp.text[:500]}")
                return None
        except Exception as e:
            print(f"[-] Error checking KPJ: {e}")
            return None

    def get_full_data(self):
        print("[*] Fetching full data from Step 1...")
        url = f"{self.base_url}/oss/input-tk-kpj-step1"
        try:
            resp = self.session.get(url, timeout=15)
            html = resp.text
            
            # Ekstraksi data menggunakan regex sesuai logika ol1.smali
            def extract(field_id):
                # Try double quotes first
                pattern = rf'id="{field_id}"[^>]*value=["\']([^"\']*)["\']'
                match = re.search(pattern, html)
                if match:
                    return match.group(1).strip()
                return "Not Found"

            def extract_select(field_id):
                # Find the select block
                pattern = rf'<select[^>]*id="{field_id}"[^>]*>(.*?)</select>'
                match = re.search(pattern, html, re.DOTALL)
                if match:
                    options_html = match.group(1)
                    # Find selected option
                    selected_match = re.search(r'<option[^>]*selected[^>]*>(.*?)</option>', options_html)
                    if selected_match:
                        return selected_match.group(1).strip()
                return "Not Found"

            results = {
                "nik": extract("no_identitas"),
                "nama": extract("nama_lengkap"),
                "ibu_kandung": extract("ibu_kandung"),
                "tempat_lahir": extract("tempat_lahir"),
                "tgl_lahir": extract("tgl_lahir"),
                "email": extract("email"),
                "handphone": extract("no_handphone"),
                "alamat": extract("alamat"),
                "kode_pos": extract("kode_pos"),
                "npwp": extract("npwp"),
                "jenis_kelamin": extract_select("jenis_kelamin"),
                "agama": extract_select("agama"),
                "golongan_darah": extract_select("golongan_darah"),
                "status_kawin": extract_select("status_kawin")
            }
            return results
        except Exception as e:
            print(f"[-] Error fetching full data: {e}")
            return None

    def run(self, kpj):
        csrf, oauth = self.get_initial_tokens()
        if not csrf:
            return {"error": "Failed to get CSRF token"}

        status = self.check_kpj(kpj, csrf, oauth)
        if not status:
            return {"error": "Failed to check KPJ status"}

        print(f"[*] Server Response: {status}")
        
        # Jika status menunjukkan KPJ valid
        data = self.get_full_data()
        if data:
            return data
        else:
            return {"error": "Failed to extract data", "server_msg": status}

if __name__ == "__main__":
    import sys
    kpj_input = sys.argv[1] if len(sys.argv) > 1 else "18024532006"
    
    scraper = OssScraper()
    result = scraper.run(kpj_input)
    print("\n[RESULT]")
    print(json.dumps(result, indent=4))