#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import asyncio
import json
import time
import random
import shutil
import re
import zipfile
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime, date

# === Auto-load .env (tanpa menimpa ENV yang sudah diexport) ===
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / '.env', override=False)
except Exception:
    pass

from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    Document,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
    CallbackQueryHandler,
)

# Selenium Imports
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

# Worker RUN
from dpt import run as run_worker

# ====== Konstanta & URL ======
URL_AUTH = 'https://www.bpjsketenagakerjaan.go.id/oss?token=ZW1haWw9U05MTlVUUkFDRVVUSUNBTEBHTUFJTC5DT00mbmliPTAyMjA0MDAyNjA4NTY='
URL_AUTH_BACKUP = 'https://bpjsketenagakerjaan.go.id/oss?token=ZW1haWw9UklaS0lUVUdBUzVAR01BSUwuQ09NJm5pYj0wOTAxMjMwMDQ2MzYy'

def sanitize_text(text: str) -> str:
    """Removes URLs from text to ensure they are not sent to Telegram."""
    if not text: return text
    return re.sub(r'https?://\S+', '[URL REMOVED]', text)

# ====== Path dasar ======
BASE_DIR = Path(__file__).parent
USERS_DIR = BASE_DIR / "users"
ALLOWED_TXT = BASE_DIR / "allowed.txt"
PROXIES_TXT = BASE_DIR / "proxies.txt"

# ====== ENV ======
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN")
ADMIN_USER_IDS = {int(x) for x in os.environ.get("ADMIN_USER_IDS", "").replace(",", " ").split() if x.strip().isdigit()}

# Helper to check display for headless mode
BOT_DISPLAY = os.environ.get("BOT_DISPLAY", "").strip()
BOT_XAUTHORITY = os.environ.get("BOT_XAUTHORITY", "").strip()
CHROME_BIN = os.environ.get("CHROME_BIN", "").strip()

REG_ERR_MSG = (
    "🛑 anda belum melakukan registrasi/ kuota habis/ masa aktif habis,\n"
    "silahkan hubungi ADMIN ."
)

async def get_captcha_balance() -> str:
    return "🤖 Saldo Captcha :  Captcha ByPass by : Ternak Lele" # Placeholder


# ====== Global state Bot ======
DRIVERS: Dict[int, webdriver.Chrome] = {}     # cid -> WebDriver instance
RUN_TASKS: Dict[int, asyncio.Task] = {}  # cid -> asyncio.Task RUN
USER_PROXY_BAGS: Dict[int, list] = {}    # cid -> list of proxies (Shuffle Bag)
ACTIVE_PROXIES: Dict[int, str] = {}      # cid -> current proxy string
IP_BAD_LOG = BASE_DIR / "ip_bad.log"

# ====== User-Agent Windows acak per CID ======
WINDOWS_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
]
UA_BY_CID: Dict[int, str] = {}

# ====== Helper waktu ======
def _nowstr() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")

def _today_str() -> str:
    return date.today().strftime("%Y-%m-%d")

# ====== Path per-user ======
def _user_paths(cid: int) -> Dict[str, Path]:
    root = USERS_DIR / str(cid)
    bahan_dir = root / "BAHAN"
    hasil_dir = root / "HASIL"
    zonk_dir = root / "ZONK"
    state_dir = root / "STATE" # Untuk 'dpt.py'
    return {
        "root": root,
        "bahan_dir": bahan_dir,
        "hasil_dir": hasil_dir,
        "zonk_dir": zonk_dir,
        "state_dir": state_dir,
        "kpj_txt": bahan_dir / "kpj.txt",
        "hasil_xlsx": hasil_dir / "list.xlsx", # Disesuaikan dengan dpt.py
        "zonk_txt": zonk_dir / "zonk.txt",
        "stop_flag": state_dir / "STOP",
        "progress_json": state_dir / "progress.json",
        "proxy_ext_zip": state_dir / f"pauth_{cid}.zip",
    }

def _ensure_user_dirs(cid: int) -> Dict[str, Path]:
    paths = _user_paths(cid)
    for key in ["root", "bahan_dir", "hasil_dir", "zonk_dir", "state_dir"]:
        paths[key].mkdir(parents=True, exist_ok=True)
    return paths

# ====== allowed.txt & quota ======
def _parse_allowed_file() -> Dict[int, Dict[str, Any]]:
    users: Dict[int, Dict[str, Any]] = {}
    if not ALLOWED_TXT.exists():
        return users
    with open(ALLOWED_TXT, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 5:
                continue
            try:
                cid = int(parts[0])
                quota_total = int(parts[1])
                used = int(parts[2])
            except ValueError:
                continue
            users[cid] = {
                "cid": cid,
                "quota_total": quota_total,
                "used": used,
                "reg_date": parts[3],
                "expiry_date": parts[4],
            }
    return users

def _save_allowed_file(users: Dict[int, Dict[str, Any]]) -> None:
    ALLOWED_TXT.parent.mkdir(parents=True, exist_ok=True)
    with open(ALLOWED_TXT, "w", encoding="utf-8") as f:
        for cid, u in users.items():
            f.write(
                f"{cid}|{int(u.get('quota_total', 0))}|{int(u.get('used', 0))}|"
                f"{u.get('reg_date', _today_str())}|{u.get('expiry_date', _today_str())}\n"
            )

def _get_user_record(cid: int) -> Optional[Dict[str, Any]]:
    users = _parse_allowed_file()
    return users.get(cid)

def _user_remaining_quota(user: Dict[str, Any]) -> int:
    try:
        total = int(user.get("quota_total", 0))
        used = int(user.get("used", 0))
    except Exception:
        return 0
    rem = total - used
    return rem if rem > 0 else 0

def _user_is_expired(user: Dict[str, Any]) -> bool:
    exp_str = (user.get("expiry_date") or "").strip()
    if not exp_str:
        return True
    try:
        exp = datetime.strptime(exp_str, "%Y-%m-%d").date()
    except Exception:
        return True
    return exp < date.today()

def _format_date_ddmmyyyy(datestr: str) -> str:
    try:
        d = datetime.strptime(datestr, "%Y-%m-%d").date()
        return f"{d.day:02d} | {d.month:02d} | {d.year}"
    except Exception:
        return datestr or "-"

def _is_admin(update: Update) -> bool:
    uid = update.effective_user.id if update.effective_user else 0
    return uid in ADMIN_USER_IDS

# ====== Access guard ======
async def _guard(update: Update) -> bool:
    uid = update.effective_user.id if update.effective_user else 0

    if _is_admin(update):
        return True

    user = _get_user_record(uid)
    
    # Check if user exists
    if not user:
        if update.message:
            await update.message.reply_text(
                "🛑 Anda tidak masuk dalam Daftar, silahkan hubungi ADMIN.\n"
                f"dengan mengirim id anda\n(CHAT ID: {uid})"
            )
        return False

    # Check if expired
    if _user_is_expired(user):
        if update.message:
            await update.message.reply_text("🛑 Masa aktif akun Anda telah habis. Silakan hubungi ADMIN.")
        return False

    # Check if quota exhausted
    if _user_remaining_quota(user) <= 0:
        if update.message:
            await update.message.reply_text("🛑 Kuota Anda telah habis. Silakan hubungi ADMIN untuk pengisian ulang.")
        return False

    return True

import logging
log = logging.getLogger(__name__)

def log_styled_ip(cid, ip):
    # Tampilan polos dan cepat
    print(f"[>] CID: {cid} | IP: {ip} | READY")

# ====== Proxy & Driver ======
def _get_next_proxy(cid: int):
    """
    Mengambil proxy berikutnya dari 'Shuffle Bag'.
    Jika bag kosong, load ulang dari proxies.txt dan shuffle.
    Ini memastikan semua proxy terpakai sebelum diulang, tapi urutannya acak.
    """
    if not PROXIES_TXT.exists():
        return None

    # Load & Shuffle jika belum ada atau kosong
    if cid not in USER_PROXY_BAGS or not USER_PROXY_BAGS[cid]:
        try:
            with open(PROXIES_TXT, "r", encoding="utf-8") as f:
                proxies = [l.strip() for l in f if l.strip() and not l.startswith("#")]
            
            if not proxies:
                return None
            
            random.shuffle(proxies)
            USER_PROXY_BAGS[cid] = proxies
            # log.info(f"Mengisi ulang Proxy Bag untuk CID {cid} dengan {len(proxies)} IP (Acak).")
        except Exception:
            return None

    # Ambil satu (pop)
    return USER_PROXY_BAGS[cid].pop()

def _create_proxy_auth_extension(u, p, cid):
    manifest = '{"version":"1.0.0","manifest_version":2,"name":"PAuth","permissions":["webRequest","webRequestBlocking","<all_urls>"],"background":{"scripts":["background.js"]}}'
    bg = 'chrome.webRequest.onAuthRequired.addListener(function(d){return{authCredentials:{username:"%s",password:"%s"}}}, {urls:["<all_urls>"]}, ["blocking"]);' % (u, p)
    path = _user_paths(cid)["proxy_ext_zip"]
    with zipfile.ZipFile(path, 'w') as zp:
        zp.writestr("manifest.json", manifest)
        zp.writestr("background.js", bg)
    return str(path)

# ====== Selenium Driver Management ======

async def _ensure_login_page(cid: int, auth_url: str = URL_AUTH) -> webdriver.Chrome:
    global DRIVERS

    # If an existing driver exists, verify it's alive, otherwise close it
    if cid in DRIVERS:
        try:
            # Simple check if driver is responsive
            DRIVERS[cid].title 
            log.info(f"Driver exists and responsive for CID {cid}. Closing to ensure clean state.")
            DRIVERS[cid].quit() # Use quit() for WebDriver
        except Exception:
            log.warning(f"Driver found but unresponsive for CID {cid}. Cleaning up.")
        finally:
             DRIVERS.pop(cid, None)

    ua = UA_BY_CID.get(cid)
    if ua is None:
        ua = random.choice(WINDOWS_USER_AGENTS)
        UA_BY_CID[cid] = ua
    
    paths = _ensure_user_dirs(cid)
    profile_dir = paths["state_dir"] / "selenium_profile"
    
    options = Options()
    options.page_load_strategy = 'eager'  # Hanya tunggu DOM, tidak tunggu semua aset selesai
    options.add_argument(f"user-agent={ua}")
    options.add_argument(f"--user-data-dir={profile_dir}")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-component-update")
    options.add_argument("--disable-background-networking")
    options.add_argument("--disable-sync")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    
    # Prefs untuk mematikan Gambar & Fonts agar sangat cepat
    prefs = {
        "profile.managed_default_content_settings.images": 2,
        "profile.managed_default_content_settings.stylesheets": 1,
        "profile.default_content_setting_values.notifications": 2,
        "profile.managed_default_content_settings.fonts": 2,
        "profile.managed_default_content_settings.plugins": 2,
    }
    options.add_experimental_option("prefs", prefs)
    
    if CHROME_BIN:
        options.binary_location = CHROME_BIN
    
    if not BOT_DISPLAY:
        options.add_argument("--headless=new")

    proxy_raw = _get_next_proxy(cid)
    ACTIVE_PROXIES[cid] = proxy_raw # Simpan untuk logging jika bermasalah
    if proxy_raw:
        h, pt, u, pw = None, None, None, None
        if proxy_raw.startswith('http'):
            m = re.match(r'https?://([^:]+):([^@]+)@([^:]+):(\d+)', proxy_raw)
            if m: u, pw, h, pt = m.groups()
        else:
            p = proxy_raw.split(':')
            if len(p) == 4: h, pt, u, pw = p
            elif len(p) == 2: h, pt = p
        
        if h and pt:
            options.add_argument(f'--proxy-server=http://{h}:{pt}')
            if u and pw: options.add_extension(_create_proxy_auth_extension(u, pw, cid))
            options.add_argument("--proxy-bypass-list=<-loopback>")
            options.add_argument("--ignore-certificate-errors")

    # Environment for the driver
    driver_env = os.environ.copy()
    if BOT_DISPLAY:
        driver_env["DISPLAY"] = BOT_DISPLAY
    if BOT_XAUTHORITY:
        driver_env["XAUTHORITY"] = BOT_XAUTHORITY

    # Run blocking Selenium setup in a thread to avoid freezing bot
    def _init_driver():
        service = Service(env=driver_env)
        driver = webdriver.Chrome(service=service, options=options)
        
        current_ip = "Unknown"
        try:
            driver.get("https://api.ipify.org")
            current_ip = driver.find_element(By.TAG_NAME, "body").text.strip()
        except Exception as e:
            log.warning(f"Gagal mengambil IP: {e}")
        
        driver.get(auth_url)
        return driver, current_ip

    try:
        log.info(f"Menginisialisasi Selenium Chrome untuk CID {cid}...")
        driver, current_ip = await asyncio.to_thread(_init_driver)
        DRIVERS[cid] = driver
        
        # Log to terminal clearly with style
        log_styled_ip(cid, current_ip)
        
        return driver, current_ip
    except Exception as e:
        log.error(f"Gagal init Selenium untuk CID {cid}: {e}")
        raise

async def _wipe_browser_data(cid: int):
    driver = DRIVERS.pop(cid, None)
    if driver:
        try:
            # Run blocking quit in thread
            await asyncio.to_thread(driver.quit)
        except Exception:
            pass
    
    paths = _user_paths(cid)
    if paths["proxy_ext_zip"].exists():
        try:
            paths["proxy_ext_zip"].unlink()
        except Exception:
            pass


# ====== UI helpers ======
def _user_main_keyboard(is_admin: bool, is_running: bool = False) -> ReplyKeyboardMarkup:
    login_text = "LOGIN (OFF)" if is_running else "LOGIN"
    rows = [
        [KeyboardButton(login_text), KeyboardButton("RUN")],
        [KeyboardButton("STATUS"), KeyboardButton("TERIMA HASIL")],
        [KeyboardButton("KIRIM KPJ"), KeyboardButton("HAPUS")],
        [KeyboardButton("STOP")],
    ]
    if is_admin:
        rows.append([KeyboardButton("ADMIN")])
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)

def _admin_keyboard() -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton("DAFTAR USER"), KeyboardButton("STATUS USER")],
        [KeyboardButton("TAMBAH USER"), KeyboardButton("HAPUS USER")],
        [KeyboardButton("TAMBAH KUOTA"), KeyboardButton("SET MASA AKTIF")],
        [KeyboardButton("TERIMA HASIL ADMIN"), KeyboardButton("BROADCAST")],
        [KeyboardButton("BATAL")],
    ]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)

def _format_user_status_text(cid: int, user: Dict[str, Any]) -> str:
    total = int(user.get("quota_total", 0))
    used = int(user.get("used", 0))
    sisa = max(0, total - used)
    reg_fmt = _format_date_ddmmyyyy(user.get("reg_date", ""))
    exp_fmt = _format_date_ddmmyyyy(user.get("expiry_date", ""))

    paths = _user_paths(cid)
    has_hasil = paths["hasil_xlsx"].exists()
    has_zonk = paths["zonk_txt"].exists()

    return (
        f"CID : {cid}\n"
        f"KUOTA = {total}\n"
        f"Digunakan = {used}\n"
        f"Sisa = {sisa}\n\n"
        f"Tanggal Regist : {reg_fmt}\n"
        f"Masa aktif s/d : {exp_fmt}\n"
        f"HASIL {'✅' if has_hasil else '❌'}\n"
        f"ZONK {'✅' if has_zonk else '❌'}"
    )

def _render_progress_bar(done: int, total: int, length: int = 20) -> str:
    if total <= 0:
        return "░" * length + " 0%"
    ratio = max(0.0, min(1.0, done / total))
    filled = int(ratio * length)
    filled = min(length, max(0, filled))
    empty = length - filled
    bar = "▓" * filled + "░" * empty
    percent = int(ratio * 100)
    return f"{bar} {percent}%"

# ====== /start ======
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cid = update.effective_user.id
    is_running = cid in RUN_TASKS and not RUN_TASKS[cid].done()
    kb = _user_main_keyboard(is_admin=_is_admin(update), is_running=is_running)
    await update.message.reply_text("Pilih aksi:", reply_markup=kb)

# ====== /progress ======
async def cmd_progress(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if not update.message: return

    cid = update.effective_user.id
    paths = _user_paths(cid)
    prog_path = paths["progress_json"]

    if not prog_path.exists():
        await update.message.reply_text("Tidak ada proses RUN yang sedang berjalan atau file progress tidak ditemukan.")
        return

    try:
        with open(prog_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        total = int(data.get("total", 0))
        done = int(data.get("done", 0))
        status = (data.get("status") or "unknown").lower()
        last_kpj = data.get("last_kpj", "")
        note = data.get("note", "")
        updated_at_str = data.get("updated_at", "")
        hasil_count = data.get("hasil_count", 0)
        zonk_count = data.get("zonk_count", 0)


        # Cek jika proses masih 'running'
        task = RUN_TASKS.get(cid)
        is_running = task and not task.done()
        
        if not is_running:
             # Jika worker sudah selesai tapi file progress belum update, anggap selesai
            if status == "running":
                 status = "Selesai"
        
        # Cek kesegaran data
        is_fresh = False
        if updated_at_str:
            try:
                updated_dt = datetime.fromisoformat(updated_at_str)
                if (datetime.now() - updated_dt).total_seconds() < 60:
                    is_fresh = True
            except:
                pass
        
        if status == "running" and not is_fresh:
            status = "Stale (tidak ada update > 1 menit)"

        bar = _render_progress_bar(done, total)
        lines = [
            f"Progres: {done}/{total}",
            bar,
            f"HASIL: {hasil_count} | ZONK: {zonk_count}",
            f"Status: {status}",
        ]
        if last_kpj:
            lines.append(f"KPJ Terakhir: `{last_kpj}`")
        if note:
            lines.append(f"Catatan: {note}")

        # Tambahkan tombol STOP jika sedang berjalan
        keyboard = None
        if is_running:
            keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("⏹️ STOP ⏹️", callback_data="stop_run")]])

        await update.message.reply_text(sanitize_text("\n".join(lines)), parse_mode="Markdown", reply_markup=keyboard)

    except (json.JSONDecodeError, KeyError) as e:
        await update.message.reply_text(sanitize_text(f"Gagal membaca file progress. File mungkin rusak atau dalam proses penulisan. Error: {e}"))
    except Exception as e:
        await update.message.reply_text(sanitize_text(f"Terjadi error saat membaca progress: {e}"))


# ====== LOGIN handler ======
async def on_login_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return
    cid = update.effective_user.id if update.effective_user else 0

    task = RUN_TASKS.get(cid)
    if task and not task.done():
        await update.message.reply_text(
            sanitize_text("Sedang RUN untuk akun ini.\nSilakan tekan STOP dulu jika ingin LOGIN ulang.")
        )
        return

    try:
        await update.message.reply_text(sanitize_text("Mempersiapkan browser Pribadi Lele..."))
        await _ensure_login_page(cid)
        
        await update.message.reply_text(
            sanitize_text("Browser siap. Silakan tekan RUN untuk memulai.")
        )

    except Exception as e:
        await update.message.reply_text(sanitize_text(f"Gagal mempersiapkan browser: {e}"))

async def on_login_off_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if not update.message: return
    await update.message.reply_text(sanitize_text("LOGIN tidak bisa dilakukan saat proses RUN sedang berjalan. Harap STOP terlebih dahulu."))

# ====== RUN handler ======

async def run_worker_and_notify(cid: int, initial_driver: webdriver.Chrome, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Runs the worker, handles re-login attempts, and sends notifications."""
    
    current_auth_url = URL_AUTH # Start with the primary URL
    relogin_attempts = 0
    # max_relogin_attempts removed for infinite retry

    try:
        while True:
            log.info(f"Memulai/Melanjutkan proses scraping untuk CID {cid}. Percobaan re-login: {relogin_attempts}")
            
            # If it's a re-login attempt, set up a fresh page
            driver_for_worker = initial_driver
            if relogin_attempts > 0:
                # User requested to NOT send message during relogin
                try:
                    # Wipe existing browser data/process before re-login to ensure a fresh start
                    await _wipe_browser_data(cid)
                    driver_for_worker, current_ip = await _ensure_login_page(cid, auth_url=current_auth_url)
                    # IP notification removed as per user request
                except Exception as e:
                    log.error(f"Gagal re-login: {e}")
                    # await ctx.bot.send_message(chat_id=cid, text=sanitize_text(f"❌ Gagal mengatur halaman login setelah re-login: {e}. Mencoba lagi dalam 30 detik..."))
                    await asyncio.sleep(10)
                    relogin_attempts += 1
                    continue
            
            result = await run_worker(cid, driver_for_worker)

            if result == "finished":
                await ctx.bot.send_message(chat_id=cid, text=sanitize_text("✅ Proses scraping KPJ telah selesai!"))
                break # Exit the loop
            elif result == "stopped":
                # Stopped by user (handled in dpt.py usually, but good to check)
                break
            elif result in ["relogin_required", "rotate_ip", "timeout", "batch_limit"]:
                # Semua kondisi error/batch akan memicu rotasi IP tanpa henti
                relogin_attempts += 1
                is_error = result != "batch_limit"
                reason = "Batch Limit" if result == "batch_limit" else f"Error ({result})"
                
                # Log bad IP jika itu error
                if is_error:
                    bad_proxy = ACTIVE_PROXIES.get(cid, "Unknown")
                    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    with open(IP_BAD_LOG, "a", encoding="utf-8") as f:
                        f.write(f"[{ts}] CID: {cid} | Proxy: {bad_proxy} | Reason: {result}\n")
                    print(f"\n\033[91m[!] BAD IP LOGGED: {bad_proxy} | Reason: {result}\033[0m")

                token_name = "UTAMA" if current_auth_url == URL_AUTH else "CADANGAN"
                print(f"\n\033[91m[!] {reason} DETECTED! Ganti IP & Lanjut...\033[0m")
                await asyncio.sleep(5) 
                
                # Switch URL (optional, but good for auth issues)
                if current_auth_url == URL_AUTH:
                    current_auth_url = URL_AUTH_BACKUP
                else:
                    current_auth_url = URL_AUTH
                continue # Loop again (Rotate IP)

            elif result == "auth_failed": 
                await ctx.bot.send_message(chat_id=cid, text=sanitize_text(f"🛑 Proses terhenti: Autentikasi gagal pada URL {'cadangan' if current_auth_url == URL_AUTH_BACKUP else 'utama'}."))
                break 
            elif result == "no_bahan":
                await ctx.bot.send_message(chat_id=cid, text=sanitize_text("🛑 Proses terhenti: File bahan (KPJ) tidak ditemukan atau kosong."))
                break 
            else: # Any other unexpected result
                # Default behavior: Try to rotate instead of dying
                log.warning(f"⚠️ Status tidak dikenal: {result}. Mencoba rotasi IP.")
                relogin_attempts += 1
                await asyncio.sleep(5)
                continue
            
    except Exception as e:
        log.error(f"❗ Terjadi error tak terduga saat proses scraping untuk CID {cid}: {e}", exc_info=True)
        await ctx.bot.send_message(chat_id=cid, text=sanitize_text(f"❗ Terjadi error tak terduga saat proses scraping: {e}"))
    finally:
        # Clean up the task from the RUN_TASKS dictionary
        RUN_TASKS.pop(cid, None)
        # Ensure browser data is wiped after the task finishes or stops
        await _wipe_browser_data(cid)
        # Update the keyboard to show LOGIN instead of LOGIN (OFF)
        is_admin = _is_admin(update)
        kb = _user_main_keyboard(is_admin=is_admin, is_running=False)
        await ctx.bot.send_message(chat_id=cid, text=sanitize_text("Keyboard diperbarui."), reply_markup=kb)


async def on_run_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return
    
    cid = update.effective_user.id if update.effective_user else 0

    task = RUN_TASKS.get(cid)
    if task and not task.done():
        await update.message.reply_text(sanitize_text("RUN sedang berjalan untuk akun ini.\nTekan STOP untuk menghentikan."))
        return

    # Call _ensure_login_page to set up the browser and perform initial navigation
    try:
        driver = DRIVERS.get(cid)
        if not driver: # Check if driver exists
             await ctx.bot.send_message(chat_id=cid, text=sanitize_text("Belum ada sesi LOGIN aktif.\nMemulai login otomatis..."))
             driver, current_ip = await _ensure_login_page(cid) 
             # IP notification removed as per user request
        
    except Exception as e:
        log.error(f"Gagal mempersiapkan browser untuk RUN CID {cid}: {e}")
        await ctx.bot.send_message(chat_id=cid, text=sanitize_text(f"Gagal mempersiapkan browser: {e}"))
        return
    
    paths = _ensure_user_dirs(cid)
    kpj_path = paths["kpj_txt"]
    if not kpj_path.exists() or kpj_path.stat().st_size == 0:
        await ctx.bot.send_message(chat_id=cid, text=sanitize_text("File BAHAN (kpj.txt) tidak ada atau kosong. Kirim KPJ dulu, lalu RUN."))
        return

    # Hapus flag stop lama jika ada
    if paths["stop_flag"].exists():
        paths["stop_flag"].unlink()

    # Buat task & update keyboard
    app = ctx.application
    run_task = app.create_task(run_worker_and_notify(cid, driver, update, ctx))
    RUN_TASKS[cid] = run_task
    
    kb = _user_main_keyboard(is_admin=_is_admin(update), is_running=True)
    await ctx.bot.send_message(chat_id=cid, text=sanitize_text("Memulai proses RUN...\nGunakan /progress untuk melihat progres."), reply_markup=kb)


# ====== STATUS (user) ======
async def on_status_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return

    cid = update.effective_user.id if update.effective_user else 0
    user = _get_user_record(cid)
    # _guard sudah memeriksa, tapi ini untuk memastikan user record ada
    if not user:
        await update.message.reply_text(sanitize_text(REG_ERR_MSG))
        return
    
    # Kirim pesan awal yang menunjukkan bot sedang memproses
    temp_message = await update.message.reply_text(sanitize_text("Sedang mengambil status dan saldo captcha..."))

    status_text = _format_user_status_text(cid, user)
    balance_text = await get_captcha_balance()
    
    if balance_text:
        status_text += f"\n\n{balance_text}"

    # Edit pesan yang sudah dikirim dengan status lengkap
    await temp_message.edit_text(sanitize_text(status_text))


# ====== TERIMA HASIL (user) ======
async def on_terima_hasil_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return
    cid = update.effective_user.id if update.effective_user else 0

    paths = _ensure_user_dirs(cid)
    lpath = paths["hasil_xlsx"]
    zpath = paths["zonk_txt"]

    sent_any = False
    if lpath.exists():
        try:
            await update.message.reply_document(document=open(lpath, "rb"), filename="HASIL.xlsx")
            sent_any = True
        except Exception as e:
            await update.message.reply_text(sanitize_text(f"Gagal mengirim HASIL.xlsx: {e}"))

    if zpath.exists():
        try:
            await update.message.reply_document(document=open(zpath, "rb"), filename="ZONK.txt")
            sent_any = True
        except Exception as e:
            await update.message.reply_text(sanitize_text(f"Gagal mengirim ZONK.txt: {e}"))

    if not sent_any:
        await update.message.reply_text(sanitize_text(f"🛑 Tidak ada file HASIL/ZONK di server untuk akun ini ({cid})"))

# ====== KIRIM KPJ (user) ======
async def on_kirim_kpj_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return
    msg = (
        "Silakan kirim atau forward file *teks* berformat `.txt` yang berisi daftar KPJ.\n"
        "- Nama file bebas, yang penting formatnya `.txt`.\n"
        "- File akan otomatis disimpan/di-*append* ke BAHAN (`kpj.txt`).\n\n"
        "Setelah terkirim, kamu bisa tekan *RUN* untuk memproses."
    )
    await update.message.reply_text(msg, parse_mode="Markdown")


# ====== HAPUS (submenu user) ======
async def on_hapus_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update):
        return
    if not update.message:
        return
    ctx.user_data["hapus_mode"] = True
    kb = ReplyKeyboardMarkup(
        [
            [KeyboardButton("HAPUS HASIL"), KeyboardButton("HAPUS KPJ")],
            [KeyboardButton("HAPUS ZONK"), KeyboardButton("BATAL")],
        ],
        resize_keyboard=True,
    )
    await update.message.reply_text("Pilih file yang ingin dihapus:", reply_markup=kb)

async def _hapus_file_generic(update: Update, kind: str):
    if not update.message:
        return
    cid = update.effective_user.id if update.effective_user else 0
    paths = _ensure_user_dirs(cid)

    if kind == "hasil":
        path = paths["hasil_xlsx"]
        label = "HASIL (list.xlsx)"
    elif kind == "kpj":
        path = paths["kpj_txt"]
        label = "BAHAN (kpj.txt)"
    elif kind == "zonk":
        path = paths["zonk_txt"]
        label = "ZONK (zonk.txt)"
    else:
        return

    if path.exists():
        try:
            path.unlink()
            await update.message.reply_text(f"File {label} berhasil dihapus.")
        except Exception as e:
            await update.message.reply_text(f"Gagal menghapus {label}: {e}")
    else:
        await update.message.reply_text(f"File {label} tidak ditemukan.")

async def on_hapus_hasil(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if "hapus_mode" not in ctx.user_data: return
    await _hapus_file_generic(update, "hasil")

async def on_hapus_kpj(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if "hapus_mode" not in ctx.user_data: return
    await _hapus_file_generic(update, "kpj")

async def on_hapus_zonk(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if "hapus_mode" not in ctx.user_data: return
    await _hapus_file_generic(update, "zonk")


# ====== STOP handler ======
async def on_stop_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    if not update.message: return

    cid = update.effective_user.id if update.effective_user else 0
    task = RUN_TASKS.get(cid)
    paths = _ensure_user_dirs(cid)
    is_admin = _is_admin(update)

    # Sedang RUN
    if task and not task.done():
        try:
            with open(paths["stop_flag"], "w", encoding="utf-8") as f:
                f.write(_nowstr())
            
            # Ambil KPJ terakhir dari progress
            last_kpj = ""
            if paths["progress_json"].exists():
                with open(paths["progress_json"], "r") as f:
                    data = json.load(f)
                    last_kpj = data.get("last_kpj", "")
            
            msg = "⏹️ Sinyal STOP telah dikirim. Proses akan berhenti."
            if last_kpj:
                msg += f"\nKPJ Terakhir yg di proses: `{last_kpj}`"

            await _wipe_browser_data(cid) # Tutup juga browsernya
            kb = _user_main_keyboard(is_admin=is_admin, is_running=False)
            await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=kb)

        except Exception as e:
            await update.message.reply_text(f"Error saat menghentikan: {e}")
        return

    # Sesi LOGIN saja
    if cid in DRIVERS:
        await _wipe_browser_data(cid)
        kb = _user_main_keyboard(is_admin=is_admin, is_running=False)
        await update.message.reply_text("⏹️ Sesi LOGIN dihentikan dan browser ditutup.", reply_markup=kb)
        return

    kb = _user_main_keyboard(is_admin=is_admin, is_running=False)
    await update.message.reply_text("Tidak ada sesi LOGIN atau RUN yang sedang berjalan.", reply_markup=kb)


async def on_stop_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer("Mengirim sinyal STOP...")

    cid = query.from_user.id
    task = RUN_TASKS.get(cid)
    paths = _ensure_user_dirs(cid)

    if task and not task.done():
        try:
            with open(paths["stop_flag"], "w", encoding="utf-8") as f:
                f.write(_nowstr())
            
            last_kpj = ""
            if paths["progress_json"].exists():
                with open(paths["progress_json"], "r") as f:
                    data = json.load(f)
                    last_kpj = data.get("last_kpj", "")

            msg = "⏹️ Sinyal STOP terkirim. Proses akan berhenti."
            if last_kpj:
                msg += f"\nKPJ Terakhir yg di proses: `{last_kpj}`"

            await _wipe_browser_data(cid)
            await query.edit_message_text(text=f"{query.message.text}\n\n{msg}", parse_mode="Markdown")

        except Exception as e:
            await query.edit_message_text(text=f"{query.message.text}\n\n Gagal mengirim sinyal: {e}", parse_mode="Markdown")
    else:
        await query.edit_message_text(text=f"{query.message.text}\n\nProses sudah tidak berjalan.", parse_mode="Markdown")


# ====== ADMIN menu & fungsi ======
async def on_admin_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = None
    await update.message.reply_text("Menu ADMIN:", reply_markup=_admin_keyboard())

# ---- ADMIN BUTTON HANDLERS ----
async def on_admin_daftar_user(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    users = _parse_allowed_file()
    if not users:
        await update.message.reply_text("Belum ada user di allowed.txt")
        return
    lines = [f"DAFTAR USER (total: {len(users)})"]
    for cid, u in sorted(users.items()):
        sisa = _user_remaining_quota(u)
        exp_fmt = _format_date_ddmmyyyy(u.get('expiry_date', ''))
        lines.append(f"CID `{cid}` | Sisa {sisa} | Exp `{exp_fmt}`")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

async def on_admin_status_user(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "status_user_wait_cid"
    await update.message.reply_text("Kirim *CID* user yang ingin dicek:", parse_mode="Markdown")

async def on_admin_tambah_user(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "tambah_user_wait_data"
    await update.message.reply_text("Kirim data user:\n`CID|KUOTA|YYYY-MM-DD`\n\nContoh:\n`123456789|100|2025-12-31`", parse_mode="Markdown")

async def on_admin_hapus_user(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "hapus_user_wait_cid"
    await update.message.reply_text("Kirim *CID* user yang ingin dihapus:", parse_mode="Markdown")

async def on_admin_tambah_kuota(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "tambah_kuota_wait_data"
    await update.message.reply_text("Kirim data:\n`CID|JUMLAH_TAMBAHAN`\n\nContoh:\n`123456789|50`", parse_mode="Markdown")

async def on_admin_set_masa_aktif(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "set_masa_aktif_wait_data"
    await update.message.reply_text("Kirim data:\n`CID|YYYY-MM-DD`\n\nContoh:\n`123456789|2025-12-31`", parse_mode="Markdown")

async def on_admin_terima_hasil(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "hasil_admin_wait_cid"
    await update.message.reply_text("Kirim *CID* user yang ingin diambil filenya:", parse_mode="Markdown")

async def on_admin_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not _is_admin(update): return
    ctx.user_data["admin_state"] = "broadcast_wait_text"
    await update.message.reply_text("Kirim pesan untuk broadcast ke semua user terdaftar:", parse_mode="Markdown")


# ====== BATAL ======
async def on_batal_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    
    ctx.user_data.pop("admin_state", None)
    ctx.user_data.pop("hapus_mode", None)
    
    cid = update.effective_user.id
    is_running = cid in RUN_TASKS and not RUN_TASKS[cid].done()
    is_admin = _is_admin(update)
    await update.message.reply_text("Dibatalkan. Kembali ke menu utama.", reply_markup=_user_main_keyboard(is_admin, is_running))

# ====== Text handler (untuk state ADMIN) ======
async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text: return
        
    text = update.message.text.strip()
    admin_state = ctx.user_data.get("admin_state")

    if not admin_state or not _is_admin(update):
        # Jika bukan admin dan bukan state admin, abaikan
        return

    users = _parse_allowed_file()
    
    if admin_state == "status_user_wait_cid":
        try:
            target_cid = int(text)
            user = users.get(target_cid)
            if not user:
                await update.message.reply_text(f"User dengan CID {target_cid} tidak ditemukan.")
            else:
                await update.message.reply_text(_format_user_status_text(target_cid, user))
        except ValueError:
            await update.message.reply_text("CID tidak valid. Kirim angka saja.")
    
    elif admin_state == "tambah_user_wait_data":
        try:
            parts = [p.strip() for p in text.split("|")]
            target_cid, kuota_str, exp_str = parts
            target_cid = int(target_cid)
            kuota = int(kuota_str)
            datetime.strptime(exp_str, "%Y-%m-%d")
            
            existing = users.get(target_cid, {})
            users[target_cid] = {
                "cid": target_cid,
                "quota_total": kuota,
                "used": existing.get("used", 0),
                "reg_date": existing.get("reg_date", _today_str()),
                "expiry_date": exp_str,
            }
            _save_allowed_file(users)
            await update.message.reply_text(f"User {target_cid} disimpan. Kuota={kuota}, Exp={exp_str}")
        except Exception:
            await update.message.reply_text("Format salah. Contoh:\n`123456789|100|2025-12-31`", parse_mode="Markdown")

    elif admin_state == "hapus_user_wait_cid":
        try:
            target_cid = int(text)
            if target_cid in users:
                users.pop(target_cid)
                _save_allowed_file(users)
                await update.message.reply_text(f"User {target_cid} telah dihapus.")
            else:
                await update.message.reply_text(f"User {target_cid} tidak ditemukan.")
        except ValueError:
            await update.message.reply_text("CID tidak valid.")
            
    elif admin_state == "tambah_kuota_wait_data":
        try:
            target_cid_str, tambahan_str = [p.strip() for p in text.split("|")]
            target_cid = int(target_cid_str)
            tambahan = int(tambahan_str)
            user = users.get(target_cid)
            if not user:
                await update.message.reply_text(f"User {target_cid} tidak ditemukan.")
            else:
                user["quota_total"] = int(user.get("quota_total", 0)) + tambahan
                _save_allowed_file(users)
                await update.message.reply_text(f"Kuota user {target_cid} ditambah {tambahan}. Total baru: {user['quota_total']}")
        except Exception:
            await update.message.reply_text("Format salah. Contoh:\n`123456789|50`", parse_mode="Markdown")

    elif admin_state == "set_masa_aktif_wait_data":
        try:
            target_cid_str, exp_str = [p.strip() for p in text.split("|")]
            target_cid = int(target_cid_str)
            datetime.strptime(exp_str, "%Y-%m-%d")
            user = users.get(target_cid)
            if not user:
                await update.message.reply_text(f"User {target_cid} tidak ditemukan.")
            else:
                user["expiry_date"] = exp_str
                _save_allowed_file(users)
                await update.message.reply_text(f"Masa aktif user {target_cid} diubah menjadi {exp_str}")
        except Exception:
            await update.message.reply_text("Format salah. Contoh:\n`123456789|2025-12-31`", parse_mode="Markdown")

    elif admin_state == "hasil_admin_wait_cid":
        try:
            target_cid = int(text)
            paths = _user_paths(target_cid)
            lpath, zpath = paths["hasil_xlsx"], paths["zonk_txt"]
            sent = False
            if lpath.exists():
                await update.message.reply_document(open(lpath, 'rb'), filename=f"HASIL_{target_cid}.xlsx")
                sent = True
            if zpath.exists():
                await update.message.reply_document(open(zpath, 'rb'), filename=f"ZONK_{target_cid}.txt")
                sent = True
            if not sent:
                await update.message.reply_text(f"Tidak ada file HASIL/ZONK untuk CID {target_cid}")
        except ValueError:
            await update.message.reply_text("CID tidak valid.")
        except Exception as e:
            await update.message.reply_text(f"Gagal mengirim file: {e}")

    elif admin_state == "broadcast_wait_text":
        all_cids = set(users.keys())
        sent = failed = 0
        for cid in all_cids:
            try:
                await ctx.bot.send_message(chat_id=cid, text=f"-- PESAN ADMIN --\n\n{text}")
                sent += 1
                await asyncio.sleep(0.1)
            except Exception:
                failed += 1
        await update.message.reply_text(f"Broadcast selesai.\nBerhasil: {sent}\nGagal: {failed}")

    # Reset state dan kembali ke menu admin
    ctx.user_data.pop("admin_state", None)
    await update.message.reply_text("Kembali ke menu ADMIN:", reply_markup=_admin_keyboard())

# ====== Document Handler (BAHAN) ======
async def on_document(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not await _guard(update): return
    msg = update.message
    if not msg or not msg.document or not msg.document.file_name.lower().endswith(".txt"):
        await msg.reply_text("File harus berformat .txt untuk dijadikan BAHAN (kpj.txt).")
        return

    cid = update.effective_user.id
    paths = _ensure_user_dirs(cid)
    kpj_path = paths["kpj_txt"]

    try:
        tg_file = await msg.document.get_file()
        
        # Download ke memory
        content_bytes = await tg_file.download_as_bytearray()
        content = content_bytes.decode('utf-8', errors='ignore')

        added = 0
        with open(kpj_path, "a", encoding="utf-8") as f:
            for line in content.splitlines():
                k = line.strip()
                if k:
                    f.write(k + "\n")
                    added += 1
        
        await msg.reply_text(f"✅ File BAHAN berhasil ditambahkan ({added} baris).")
    except Exception as e:
        await msg.reply_text(f"Gagal memproses file BAHAN: {e}")


# ====== Main ======
def main():
    if not TELEGRAM_TOKEN:
        print("ERROR: TELEGRAM_TOKEN belum di-set di ENV/.env", file=sys.stderr)
        sys.exit(1)

    app = Application.builder().token(TELEGRAM_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("progress", cmd_progress))
    app.add_handler(CallbackQueryHandler(on_stop_callback, pattern="^stop_run$"))
    
    # User menu buttons
    app.add_handler(MessageHandler(filters.Regex("^LOGIN$"), on_login_button))
    app.add_handler(MessageHandler(filters.Regex("^LOGIN \(OFF\)$"), on_login_off_button))
    app.add_handler(MessageHandler(filters.Regex("^RUN$"), on_run_button))
    app.add_handler(MessageHandler(filters.Regex("^STATUS$"), on_status_button))
    app.add_handler(MessageHandler(filters.Regex("^TERIMA HASIL$"), on_terima_hasil_button))
    app.add_handler(MessageHandler(filters.Regex("^KIRIM KPJ$"), on_kirim_kpj_button))
    app.add_handler(MessageHandler(filters.Regex("^HAPUS$"), on_hapus_button))
    app.add_handler(MessageHandler(filters.Regex("^STOP$"), on_stop_button))
    
    # Hapus sub-menu
    app.add_handler(MessageHandler(filters.Regex("^HAPUS HASIL$"), on_hapus_hasil))
    app.add_handler(MessageHandler(filters.Regex("^HAPUS KPJ$"), on_hapus_kpj))
    app.add_handler(MessageHandler(filters.Regex("^HAPUS ZONK$"), on_hapus_zonk))

    # ADMIN menu & buttons
    app.add_handler(MessageHandler(filters.Regex("^ADMIN$"), on_admin_menu))
    app.add_handler(MessageHandler(filters.Regex("^DAFTAR USER$"), on_admin_daftar_user))
    app.add_handler(MessageHandler(filters.Regex("^STATUS USER$"), on_admin_status_user))
    app.add_handler(MessageHandler(filters.Regex("^TAMBAH USER$"), on_admin_tambah_user))
    app.add_handler(MessageHandler(filters.Regex("^HAPUS USER$"), on_admin_hapus_user))
    app.add_handler(MessageHandler(filters.Regex("^TAMBAH KUOTA$"), on_admin_tambah_kuota))
    app.add_handler(MessageHandler(filters.Regex("^SET MASA AKTIF$"), on_admin_set_masa_aktif))
    app.add_handler(MessageHandler(filters.Regex("^TERIMA HASIL ADMIN$"), on_admin_terima_hasil))
    app.add_handler(MessageHandler(filters.Regex("^BROADCAST$"), on_admin_broadcast))
    app.add_handler(MessageHandler(filters.Regex("^BATAL$"), on_batal_button))

    # Document handler
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))

    # Fallback text handler (untuk admin states)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    print("Bot started...")
    app.run_polling()

if __name__ == "__main__":
    main()
