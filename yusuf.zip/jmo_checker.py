import requests
import uuid
import json
import time
import os

class JMOChecker:
    def __init__(self):
        # URL Endpoint dari file smali/tL.smali
        self.url = "https://api-jmo.bpjsketenagakerjaan.go.id/kepesertaan/cekinfo"
        
        # Headers (disesuaikan agar mirip dengan traffic dari aplikasi Android)
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "okhttp/4.12.0"  # User agent standar library di Android
        }
        
        # Ambil segmen dari environment variable, default ke PU, BPU, PMI jika tidak ada
        env_segmen = os.getenv("SEGMEN")
        if env_segmen:
            # Jika user mengisi SEGMEN=PU,BPU maka jadi ["PU", "BPU"]
            self.segments = [s.strip().upper() for s in env_segmen.split(",")]
        else:
            self.segments = ["PU", "BPU", "PMI"]

    def check_status(self, nik, kpj, nama, tgl_lahir):
        """
        Melakukan pengecekan status JMO.
        tgl_lahir format biasanya: YYYY-MM-DD (misal: 1990-01-31)
        """
        
        # Generate Device ID acak (sama seperti logic java.util.UUID.randomUUID())
        device_id = str(uuid.uuid4())

        # Loop sesuai logika di method a(...) pada tL.smali
        last_error_message = ""

        for segment in self.segments:
            # Pindah ke sini supaya bisa di-retry jika server sibuk
            max_retries = 3
            attempt = 0
            
            while attempt < max_retries:
                attempt += 1
                
                # Payload JSON sesuai konstruksi di smali
                payload = {
                    "deviceId": device_id,
                    "chId": "01",
                    "nik": nik,
                    "kpj": kpj,
                    "nama": nama,
                    "tglLahir": tgl_lahir,
                    "kewarganegaraan": "WNI",
                    "passpor": nik,  # Di smali, field 'passpor' diisi dengan variabel 'p1' (NIK)
                    "kodeSegmen": segment
                }

                try:
                    response = requests.post(
                        self.url, 
                        json=payload, 
                        headers=self.headers, 
                        timeout=30
                    )
                    
                    if response.status_code == 200 or response.status_code == 400:
                        try:
                            data = response.json()
                        except json.JSONDecodeError:
                            break # Lanjut segment berikutnya jika json error

                        msg_raw = data.get("message", "")
                        message = msg_raw.lower()
                        is_successful = data.get("isSuccessful", False)

                        # --- LOGIKA RETRY JIKA SERVER SIBUK ---
                        if "peningkatan jumlah pengguna" in message or "coba kembali beberapa saat lagi" in message:
                            if attempt < max_retries:
                                time.sleep(2) # Jeda 2 detik sebelum coba lagi
                                continue # Lakukan loop while (retry)
                        
                        # 1. Cek 'Sudah Terdaftar' (Prioritas Tertinggi)
                        if "sudah terdaftar" in message or "sudah pernah didaftarkan" in message:
                            return {
                                "status": "SUDAH_TERDAFTAR_JMO",
                                "message": msg_raw,
                                "segment": segment,
                                "raw_response": data
                            }
                        
                        # 2. Logika Khusus Segmen PU (Sesuai Permintaan)
                        if segment == "PU":
                            if "data kepesertaan tidak ditemukan" in message:
                                return {
                                    "status": "KOREKSI",
                                    "message": msg_raw,
                                    "segment": segment,
                                    "raw_response": data
                                }
                            if "permintaan ditolak" in message:
                                return {
                                    "status": "GASKEUN",
                                    "message": msg_raw,
                                    "segment": segment,
                                    "raw_response": data
                                }

                        # 3. Jika isSuccessful = true
                        if is_successful:
                            return {
                                "status": "GASKEUN",
                                "message": msg_raw,
                                "segment": segment,
                                "raw_response": data
                            }
                        
                        # Simpan pesan error terakhir jika gagal di segmen ini
                        last_error_message = msg_raw
                        break # Keluar dari while attempt, lanjut segment berikutnya
                        
                    else:
                        last_error_message = f"HTTP {response.status_code}"
                        break # Keluar dari while attempt

                except Exception as e:
                    last_error_message = str(e)
                    break # Keluar dari while attempt

        # Jika semua segmen (PU, BPU, PMI) sudah dicoba dan tidak ada yang return status di atas
        return {
            "status": "GASKEUN", 
            "message": last_error_message or "Permintaan ditolak di semua segmen",
            "raw_response": None
        }

# --- Contoh Penggunaan ---
if __name__ == "__main__":
    # Ganti dengan data dummy atau data test
    nik_target = "1234567890123456" 
    kpj_target = "123456789"
    nama_target = "BUDI SANTOSO"
    tgl_lahir_target = "1990-01-01" 

    checker = JMOChecker()
    hasil = checker.check_status(nik_target, kpj_target, nama_target, tgl_lahir_target)
    
    print("\n=== HASIL PENGECEKAN ===")
    print(json.dumps(hasil, indent=4))